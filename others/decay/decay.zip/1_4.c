#include <stdio.h>
void main(){
	printf("This is a c program.\n");
}

