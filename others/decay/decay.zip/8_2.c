#define output1(x) printf("%6.2f\n", x)
#define output2(x, y) printf("%6.2f %6.2f\n", x, y)
#define output3(x, y, z) printf("%6.2f %6.2f %6.2f\n", x, y, z)

