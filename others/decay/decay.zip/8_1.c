#define swap(a, b) ((a)^=(b)^=(a)^=(b))

