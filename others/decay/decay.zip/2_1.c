#include <stdio.h>
void main(){
    char c1, c2;
    c1 = 'a', c2 = 'b';
    printf("%c %c", c1, c2);
}
