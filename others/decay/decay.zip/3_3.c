#include <stdio.h>
int main(){
	char c1, c2;
	c1 = getchar(), c2 = getchar();
	putchar(c1);
	printf("%c\n", c2);
	return 0;
}

